dict = {"id":"1","name":"BCA","name":"BscIT","result":"Pass","Marks":"0"}
print(dict)
print("---print value---")
print(dict["name"])
print("---print length---")
print(len(dict))
x=dict.get("id")
print(x)
x=dict.keys()
print(x)
dict["Sem."]="5"
print(x)
dict ["name"]="BCOM"
print(dict)
dict.update({"id":"5"})
print(dict)
dict.update({"Sub.":"PHP"})
print(dict)
dict.pop("name")
print(dict)
dict.popitem()
print(dict)
del dict ["id"]
print(dict)
del dict
print(dict)

dict = {"id":"1","name":"BCA","result":"Pass","Marks":"0"}
for x in dict:
    print(x)
for x in dict:
    print(dict[x])
for x in dict.values():
    print(x)
for x in dict.keys():
    print(x)
for x,y in dict.items():
    print(x,y)            



# dict = {"id":"1","name":"BCA","name":"BscIT"}
# print(dict)
# print(len(dict))

# dict = {"id":"1","name":"BCA"}
# x=dict.get("id")
# print(x)
# x=dict.keys()
# print(x)

# dict = {"id":"1","name":"BCA"}
# x=dict.keys()
# print(x)
# dict["result"]="Fail"
# print(x)


# dict = {"id":"1","name":"BCA"}
# dict ["name"]="BScIT"
# print(dict)
# dict.update({"id":"2"})
# print(dict)


# dict.update({"Mark":"2"})
# print(dict)


# dict = {"id":"1","name":"BCA","result":"Pass","Marks":"0"}
# dict.pop("name")
# print(dict)
# dict.popitem()
# print(dict)

# del dict ["id"]
# print(dict)
