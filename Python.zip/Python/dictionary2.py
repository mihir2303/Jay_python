dict = {"id":"1","name":"BCA","result":"Pass","Marks":"0"}
for x in dict:
    print(x)
for x in dict:
    print(dict[x])
for x in dict.values():
    print(x)
for x in dict.keys():
    print(x)
for x,y in dict.items():
    print(x,y)