def abc(a):
    return a

print(abc(5))
b=abc(8)
print(b)

c=abc
print(c(10))