import os
fpath="C:\JAY\Python\\file_create\demo2.txt"
if os.path.exists(fpath):
    #f1=open(fpath,"a")
    #f1.write("SEmester 4 Result fail")
    f1=open(fpath,"r")
    print(f1.read())
else:
    f1=open(fpath,"x")
    print("File created")