f1=open("C:\JAY\Python\\file_create\demo.txt","x")
f1.write("BCA")
f1.close