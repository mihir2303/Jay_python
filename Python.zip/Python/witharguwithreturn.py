def sum(a,b):
        return(a+b)
print (sum(10,20))
i=sum(20,20)
print(i)