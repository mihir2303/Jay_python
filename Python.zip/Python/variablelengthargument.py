def sum(*args):
    add=0
    for i in args:
        add=add+i
    return add
print(sum(100,120,130,140,150,100,200))

    