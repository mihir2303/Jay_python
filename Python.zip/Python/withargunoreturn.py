def sum(a,b):
    print(a+b)
sum(10,20)
    