import os
if os.path.exists("C:\JAY\Python\\file_create\demo.txt"):
    os.remove("C:\JAY\Python\\file_create\demo.txt")
else:
    print("File not found")