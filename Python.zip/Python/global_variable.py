def myfunc():
    global i
    i=10
    
myfunc()
print(i)