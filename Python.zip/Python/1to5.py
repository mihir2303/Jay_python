i = 1
while (i<=5):
    print(i,end=" ")
    i=i+1

for i in range(6):
    print(i,end=" ")	