#arithmetic operation
def add(x,y):
    return x+y
def subtract(x,y):
    return x-y
def multiply(x,y):
    return x*y
def divide(x,y):
    return x/y

num1 = float (input("Enter the first no."))
num2 = float (input("Enter the second no."))

print("Choose an operation :")
print("1.Addition")
print("2.Subtract")
print("3.Multiply")
print("4.Divide")
choice = input("Enter your choice :")

if choice == '1':
    result = add(num1, num2)
    operation = "addition"
elif choice == '2':
    result = subtract(num1, num2)
    operation = "subtraction"
elif choice == '3':
    result = multiply(num1, num2)
    operation = "multiplication"
elif choice == '4':
    result = divide(num1, num2)
    operation = "division"
else:
    result = "Invalid Choice"
    operation = None
    
if operation:
    print(f"Result of {operation} is: {result}")
else:
    print(result)
