def myfunc(nm):
    return nm
obj = myfunc
print(obj("BCA"))