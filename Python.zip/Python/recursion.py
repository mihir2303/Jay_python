def result(subject):
    if(subject>0):
        ans=subject + result(subject -1)
        print(ans)
    else:
        ans=0
    return ans
result(10)