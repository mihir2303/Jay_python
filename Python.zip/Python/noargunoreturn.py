def sum():
    print("Hello world")
sum()