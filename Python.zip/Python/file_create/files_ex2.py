f1=open("C:\JAY\Python\\file_create\demo.txt","w")
f1.write("BCA sem-4")
f1.close