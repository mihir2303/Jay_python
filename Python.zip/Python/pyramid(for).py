rows=int(input("Enter no. of row:"))
for i in range(rows):
    for j in range(i+1):
        print(j+1,end=' ')
    print()