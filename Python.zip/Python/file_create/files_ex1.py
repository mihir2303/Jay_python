f1=open("C:\JAY\Python\\file_create\demo.txt","r")
if f1:
    print("File open")