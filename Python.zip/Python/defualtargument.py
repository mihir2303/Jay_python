def sum(a=10,b=20):
    return(a+b)
print(sum())
print (sum(100,120))
   