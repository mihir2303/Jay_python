number = int(input("Enter number :"))
if number > 0:
    print("Positive")
elif number == 0:
    print("Zero")
else:
    print("Nagative")